/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gerenciamentoestudantil;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

/**
 *
 * @author ana
 */
public class Arquivo {
          public void escrever(Estudante a) {
        
        OutputStream os = null;
        OutputStreamWriter osr = null;
        BufferedWriter bw = null;
        String linhaEscrever;
        
        try {
            
            os = new FileOutputStream("Arquivo.txt", true); //salvar no arquivo
            osr = new OutputStreamWriter(os); //conversor
            bw = new BufferedWriter(osr); //o q vai digitar
            
            bw.write("Estudante");
            bw.newLine();
            bw.write(a.getNome() + "\n");
            bw.write(a.getId() + "\n");
            bw.write(a.getPeriodo() + "\n");
            bw.write(a.getMateria() + "\n");
            
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            
            try {
                bw.close();
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }

    public ArrayList<Estudante> ler() {
        
        InputStream is = null;
        InputStreamReader isr = null;
        BufferedReader br = null;
        ArrayList<Estudante> acheiNoArquivo = new ArrayList<>();
        String linhaLer;
        
        try {
            
            is = new FileInputStream("Arquivo.txt");
            isr = new InputStreamReader(is);
            br = new BufferedReader(isr); 
            
            linhaLer = br.readLine();
            while(linhaLer != null) {
               if(linhaLer.contains("Estudante")) {
                   Estudante aux = new Estudante();
                   aux.setNome(br.readLine());
                   aux.setId(Integer.parseInt(br.readLine()));
                   aux.setPeriodo(Integer.parseInt(br.readLine()));
                   aux.setMateria(br.readLine());
                   acheiNoArquivo.add(aux);
               }
               linhaLer = br.readLine();
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            try {
                br.close();
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        return acheiNoArquivo;
    }
    
}
