/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gerenciamentoestudantil;

/**
 *
 * @author ana
 */
public class Estudante {
    private int id;
    private String nome;
    private int periodo;
    private String materia;
    private int nota;
    
    public void setPeriodo(int periodo){
        try {
            if (periodo > 10) {
                throw new PeriodoException();
            }
            this.periodo = periodo;
        } catch (PeriodoException e){
            e.periodoIncorreto();
        }
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public void setMateria(String materia){
    this.materia= materia; 
    }
    
    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public int getPeriodo() {
     return periodo;   
    }

    public String getMateria() {
        return materia;
    }
    
    public int getNota(){
       return nota; 
    }
    
}
